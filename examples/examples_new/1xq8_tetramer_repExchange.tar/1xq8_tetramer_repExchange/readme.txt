Example of Replica Exchange simulation using LAMMPS

Protein: Four chains of Alpha-Synuclien (PDB id 1xq8)

Range of 24 temperatures

Input file: infile.in 

Fragment Memory has been disabled due to the fragment memory library being too large to upload into GitHub
