TCL scripts used in VMD for trajectory analysis.

- center_of_mass.tcl , gyr_radius.tcl , and rog_loop_dcd.tcl are used to create a .dat file containing Radius of Gyration measurements for each frame in a trajectory. To use, load rog_loop_dcd.tcl

- ss_traj.tcl creates an ss_traj.dat file containing secondary structure assignments for each residue in the chain for each frame in a trajectory.

- pdbGen.tcl creates a separate .pdb file for each frame in a trajectory. The script must be edited to run to the desired frame.
