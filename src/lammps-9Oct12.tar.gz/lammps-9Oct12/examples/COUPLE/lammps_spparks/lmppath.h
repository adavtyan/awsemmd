#define LMPPATH /home/sjplimp/lammps 
